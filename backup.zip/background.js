let nodes = [];
let connections = [];
let n_nodes = 50;
let n_connections = 0;

function setup() {
  let canvas = createCanvas(windowWidth, windowHeight);
  n_connections = random(5,11);
  n_connections = floor(n_connections);
  canvas.position(0, 30);
  canvas.style('z-index', '-1');
  canvas.style('position', 'fixed');
  canvas.style('display', 'block');
  canvas.style('pointer-events', 'none');
  noFill();
  strokeWeight(1);
  generateNodes();
}

function generateNodes() {
  nodes = [];
  let cols = floor(width / n_nodes);
  let rows = floor(height / n_nodes);

  for (let x = 0; x < cols; x++) {
    for (let y = 0; y < rows; y++) {
      let posX = x * n_nodes + random(-10, 10)+30;
      let posY = y * n_nodes + random(-10, 10)+20;
      nodes.push(createVector(posX, posY));
    }
  }

  connections = [];
  for (let i = 0; i < nodes.length; i++) {
    
    let current = nodes[i];
    let distances = [];
    for (let j = 0; j < nodes.length; j++) {
      if (i != j) {
        let d = p5.Vector.dist(current, nodes[j]);
        distances.push({ index: j, dist: d });
      }
    }
    distances.sort((a, b) => a.dist - b.dist);
    for (let k = 0; k < n_connections; k++) {
      if (distances[k] && distances[k].dist < 150) {
        connections.push([i, distances[k].index]);
      }
    }
  }
}

function draw() {
  clear();
  background(5, 5, 5);
  stroke(random(10,11), random(15,20), random(10,12));

  // animação simples: oscilar posições dos nodes levemente
  for (let i = 0; i < nodes.length; i++) {
    let n = nodes[i];
    n.x += sin(frameCount * 0.01 + i) * 0.3;
    n.y += cos(frameCount * 0.01 + i) * 0.3;
    ellipse(n.x, n.y, 4, 4);
  }

  for (let c of connections) {
    let n1 = nodes[c[0]];
    let n2 = nodes[c[1]];
    line(n1.x, n1.y, n2.x, n2.y);
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  generateNodes();
}
